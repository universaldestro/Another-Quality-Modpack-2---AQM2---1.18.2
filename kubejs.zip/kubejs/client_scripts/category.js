//Another Quality Modpack 2


// onEvent('rei.remove.categories', event => {
//     event.yeet('twilightforest:uncrafting')
//   })